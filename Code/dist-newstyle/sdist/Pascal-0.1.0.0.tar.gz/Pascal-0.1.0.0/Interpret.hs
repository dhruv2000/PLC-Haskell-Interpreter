module Interpret 
(
    interpret,
    interpretStart,
    biOp2,
    biOp1,
    bibOp1,
    bibOp2,
    intExp

)
where

import Data
import Data.Maybe (isNothing)
import qualified Data.Map.Strict as Map

-- TODO: define auxiliary functions to aid interpretation
-- Feel free to put them here or in different modules
-- Hint: write separate evaluators for numeric and
-- boolean expressions and for statements

evalFloatExp :: Exp -> [Map.Map String (String, String)] -> String
evalFloatExp (Real x) m = (show x);
evalFloatExp (Var s) m = if isNothing $ Map.lookup s $ head m
                                  then evalFloatExp (Var s) $ tail m
                                  else show $ Map.lookup s $ head m
evalFloatExp (Var s) [m] = if isNothing $ Map.lookup s m
                                  then error("Variable " ++ s ++ " is undefined")
                                  else show $ Map.lookup s m

--THIS IS LIKELY WHERE YOU WILL INTERPRET THE INFO
biOp1 :: String -> Float -> Float
biOp1 "-" v1 = (-v1)

-- Gets called by intExp
uniOp1 :: String -> Float -> Float
uniOp1 "-" v1 = (-v1)
uniOp1 "sqrt" v1 = sqrt v1
uniOp1 "ln" v1 = log v1
uniOp1 "sin" v1 = sin v1
uniOp1 "cos" v1 = cos v1
uniOp1 "exp" v1 = exp v1

-- Gets called by intExp
biOp2 :: String -> Float -> Float -> Float
biOp2 "+" v1 v2 = v1 + v2
biOp2 "-" v1 v2 = v1 - v2
biOp2 "*" v1 v2 = v1 * v2
biOp2 "/" v1 v2 = v1 / v2

-- data Exp in data.hs
intExp :: Exp -> Float
intExp (Real v1) = v1 
intExp (Op1 op e1) = uniOp1 op (intExp e1)
intExp (Op2 op e1 e2) = biOp2 op (intExp e1) (intExp e2)

bibOp1 :: String -> Bool -> Bool
bibOp1 "Not" True = False
bibOp1 "Not" False = True

bibOp2 :: String -> Bool -> Bool -> Bool
bibOp2 "AND" b1 b2 = b1 && b2
bibOp2 "OR" b1 b2 = b1 || b2

-- relational binary operator( takes in 2 values)
relBiOp :: String -> Float -> Float -> Bool
relBiOp "<" b1 b2 = b1 < b2
relBiOp ">" b1 b2 = b1 > b2
relBiOp "<=" b1 b2 = b1 <= b2
relBiOp ">=" b1 b2 = b1 >= b2
relBiOp "=" b1 b2 = b1 == b2

-- boolean operations for top one -- and/or
boolIntExp :: BoolExp -> Bool 
boolIntExp True_C = True
boolIntExp False_C = False
boolIntExp (Not e1) = bibOp1 "NOT" (boolIntExp e1)
boolIntExp (OpB op v1 v2) = bibOp2 op (boolIntExp v1) (boolIntExp v2) 
boolIntExp (Comp op e1 e2) = relBiOp op (intExp e1) (intExp e2)
-- make sure you write test unit cases for all functions

interpret :: Program -> String;
-- Initiates interpreting with an empty global scope
interpret [] = "";
interpret x = interpretStart x Map.empty

--Starting point after gettign a global scope
interpretStart :: Program -> [Map.Map String (String, String)] -> String
interpretStart (x:xs) m = let curr = interpretStatement x m in
     head m ++ interpretStart xs $ tail m

interpretStatement :: Statement -> [Map.Map String (String, String)] -> (String, [Map.Map String (String, String)])
interpretStatement (Write a) m = (evalFloatExp a ++ "\n", m)
interpretStatement (Assign a b) maps = ("", Map.insert a evaluated $ head maps : tail maps)
