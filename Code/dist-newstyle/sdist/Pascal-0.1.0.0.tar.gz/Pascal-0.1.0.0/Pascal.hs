module Pascal
  ( module Data
  , module Wrapper
  , module Interpret
  )
  where

----------------------------------------------------------------------------
import           Data
import           Wrapper
import           Interpret
----------------------------------------------------------------------------

